﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Straight_Pawn
{
    class Customer
    {
        public int ItemIndex { get; protected set; }
        public string Name { get; protected set; }
        private string story, desc;
        private int ask;
        private double lowgo;


        //has random name
        //has lowest-go random percentage


        //is instantiated w item from list, picks story, starting ask, 
        public Customer() { }
        public Customer(string Name, string Story, string Desc, int  ItemIndex)
        {
            this.Name = Name;
            this.story = Story;
            this.desc = Desc;
            this.ItemIndex = ItemIndex;
            //TODO populate
            ask = AskInit();
            lowgo = lowgoInit();
            Console.WriteLine(lowgo.ToString());


        }
 
        private int AskInit()
        {
            Random rand = new Random();
            return rand.Next(200, 5000);
        }
        private double lowgoInit()
        {
            Random rand = new Random();
            return rand.NextDouble() * (0.8 - 0.2) + 0.2; //thx to michael on stackoverflow for this more concise way of doing this 
        }
        public string ItemStory()
        {
            return story;
        }
        public string CharDesc()
        {
            return desc;
        }
        public string assembleGreet()
        {
            List<string> intro1 = new List<string> { "I've brought in an item", "I've got something", "There's an item I've brought", "I've got this thing", "I've obtained this piece", "There's this thing I have", "I have a piece here", "I've brought an object with me", "I have got an item with me", "I've brought this object", };
            List<string> intro2 = new List<string> { "I want you to take a look at.", "I was wanting to sell", "that I wanted to get an estimate on", "that I'm looking to pawn.", "that I'm trying to get rid of", "that I want to sell.", "for you to see.", "that I'd like to sell", "that might interest you.", "that I've been thinking bbout pawning", "I am hoping to get appraised", "I'm looking to get an offer on.", "I would like to know if you're interested in buying.", "I hope you'll be interested in" };
            Random rand = new Random();
            int index1 = rand.Next(intro1.Count);
            int index2 = rand.Next(intro2.Count);

            return intro1[index1] + ' ' + intro2[index2];
        }

        public string Place()
        {
            List<string> place = new List<string> { "Here you go.", "Here it is.", "Here.", "There it is", "This is it right here.", "Rare Find right here", "One of a kind", "Voilà", "Check it out.", "Take a look.", "Check out this beauty", "Bet you've never seen one of these", "Feast your eyes!", "Take a good look." };
            Random rand = new Random();
            return place[rand.Next(0, place.Count)];
        }
        public string What()
        {
            List<string> place = new List<string> { "What?", "I don't understand...", "Pardon?", "Say again?", "I have no idea what you are talking about.", "That means nothing to me...", "What???", "Huh?", "What are you talking about?" };
            Random rand = new Random();
            return place[rand.Next(0, place.Count)];
        }

        public int Ask()
        {
            return ask;
        }
        //set lowest-go to the percentage of the want value




        //asks the asking price, prompting user to begin haggling, sending
    }
}
