﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions; //chat GPT informed me about the Regular Expression functions

namespace Straight_Pawn
{
    class Pawnstar
    {
        public string Name;
        private int funds = 20000;
        public Pawnstar(string name)
        {
            Name = name;
        }
        private bool match(string input, string[] pattern)
        {
            bool isMatch = false;
            foreach (string keyword in pattern)
            {
                if (input.ToLower().Contains(keyword))
                {
                    isMatch = true;
                    break;
                }
                else
                {
                    isMatch = false;
                }
            }
            return isMatch;
        }
        public int AcceptDeal(int total)
        {
            funds -= total;
            return funds;
        }
        public bool SeeIt(string input)
        {
            string[] pattern = { "see", "look", "show", "view", "is it", "tell", "yes", "what", "give", "interested", "let", "out","curious", "alright", "go", "listening", "sure", "yeah", "okay", "what", "please", "ok","object" };
            bool isMatch = match(input, pattern);
            return isMatch;
        }
        public int GetHaggleResp(string input)
        {
            int outcome;
            bool hasInt = isInt(input);
            string[] patternAccept = { "deal","accept", };
            string[] patternExpert = { "call", "expert", };

            if (hasInt)
            {
                outcome = 1;
            }else if(match(input, patternAccept))
            {
                outcome = 2;
            }else if(match(input, patternExpert))
            {
                outcome = 3;
            }else
            {
                outcome = 4;
            }


            return outcome;
        }
        private bool isInt(string input)
        {
            bool isInt = false;
            foreach (char c in input)
            {
                if (Char.IsDigit(c))
                {
                    isInt = true;
                    break;
                }
                else
                {
                    isInt = false;
                }
            }
            return isInt;
        }
    }
}
