﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using static System.Console;
using static System.Net.Mime.MediaTypeNames;
using System.Threading;

namespace Straight_Pawn
{
    class Game
    {
        //holds current bid
        public int CurrentBid = 0;
        const int MAX_LINE_LENGTH = 75;
        public int day = 0;
        public string pawnData = "PawnData.txt";//structure borrowed from trivia
        private string custyData = "CustyData.txt";

        public List<PawnItem> PawnList { get; } = new List<PawnItem>();
        private List<Customer> customerList = new List<Customer>();
        private List<Customer> dailyLine = new List<Customer>();

        private Pawnstar Pawnstar;

        public Game()
        {
            LoadItems();
            LoadCustomers();
            Greet();
        }
        public void TW(string input, bool pause = true) //typewriter method
        {

            int sleep = 30;
            foreach (char c in input)
            {
                if (Console.KeyAvailable) sleep = 0;
                Console.Write(c);
                Thread.Sleep(sleep);

            }

            if (pause)
            {
                
                Console.ReadKey(intercept: true); //prevent pressed skip key from printing to console
            }



        }
        public List<string> LineBreaker(string input)
        {
            List<string> lines = new List<string>();

            StringBuilder sb = new StringBuilder();

            foreach (string word in input.Split())
            {
                // If adding the next word and a space would keep the line under the maximum length,
                // append the word and a space to the StringBuilder
                if (sb.Length + word.Length + 1 <= MAX_LINE_LENGTH)
                {
                    sb.Append(word);
                    sb.Append(" ");
                }
                else
                {
                    // Otherwise, add the current line to the list of lines, clear the StringBuilder,
                    // and start a new line with the current word
                    lines.Add(sb.ToString().Trim());
                    sb.Clear();
                    sb.Append(word);
                    sb.Append(" ");
                }
            }

            // Add the final line to the list of lines
            if (sb.Length > 0)
            {
                lines.Add(sb.ToString().Trim());
            } //credit to chatGPT for helping me with the string builder


            return lines;
        }
        public string[] PronounCheck(string input)
        {
            string[] words = input.Split(' ');
            string[] pronoun = new string[] { "they", "them" };
            foreach (string word in words) //check each standalone word
            {
                if (word.ToLower().Equals("she") || word.ToLower().Equals("her"))
                {
                    pronoun = new string[] { "she", "her" };
                }
                else if (word.ToLower().Equals("he") || word.ToLower().Equals("him"))
                {
                    pronoun = new string[] { "he", "him" };
                }

            }
            return pronoun;
        }
        public string sCheck(string input)
        {
            string s = "";
            if (input.ToLower() == "they")
            {
                s = "";
            }
            else
            {
                s = "s";
            }
            return s;
        }

        public void Greet()
        {
            TW("Welcome to STRAIGHT PAWN!! \n What's your badass pawn name?");
            Pawnstar = new Pawnstar(ReadLine());
            OpenDay();

        }
        public void LoadItems()
        {
            foreach (var item in File.ReadAllLines(pawnData))
            {
                var fields = item.Split(';'); //methodology helpfully pulled from our trivia game
                PawnList.Add(new PawnItem(fields[0], fields[1], fields[2])); //TODO add values of all items and , fields[3])
            }

        }
        public void LoadCustomers()
        {
            foreach (var item in File.ReadAllLines(custyData))
            {
                Random rand = new Random();
                var fields = item.Split(';');
                customerList.Add(new Customer(fields[0], fields[1], fields[2], rand.Next(0, PawnList.Count)));
            }

        }


        public void OpenDay()
        {
            day++;
            Clear();
            //TODO create list of all customers
            PopulateLine();
            Line();
            //first customer introduction

        }

        public void PopulateLine()
        {
            Random rand = new Random();
            int lineLength = rand.Next(4, 6);
            for (var i = 0; i < lineLength; i++)
            {
                var r = rand.Next(0, customerList.Count);
                dailyLine.Add(customerList[r]);
                customerList.Remove(customerList[r]);
            }

        }

        public void Line()
        {
            foreach (var customer in dailyLine)
            {
          
                WalkUp(customer);
                Introduction(customer);
                WriteLine(Haggle(customer, Pawnstar));
                ReadKey();

            }
        }

        public void WalkUp(Customer customer)
        {

            foreach (var line in LineBreaker($"Next in line is {customer.CharDesc()}"))
            {
                TW($"{line} \n", false);

            }
            ReadKey(intercept: true);
            WriteLine("\n");
            string pronoun = char.ToUpper(PronounCheck((customer.CharDesc()))[0][0]) + PronounCheck((customer.CharDesc()))[0].Substring(1); //PronounCheck((customer.CharDesc()))[0] // index tells which pronoun variation
            string s = sCheck(pronoun);


            TW($"{pronoun} walk{s} up to the counter \n");
            
            WriteLine("\n");

        }
        public void Introduction(Customer customer)
        {
            Clear();
            TW($"{CustomerGreet(customer)}",false);
            WriteLine("");
            ShowAsk(customer);
            

            Clear();
            PlaceOnCounter(customer);
            Random rand = new Random();

        }

        public void ShowAsk(Customer customer)
        {
            bool ask = false;
            for (int i = 0; i < 5; i++)
            {
                WriteLine("Pawnstar:");
                string input = ReadLine();
                ask = Pawnstar.SeeIt(input); // just replace this with a press key and a random dialogue
                if (ask == false)
                {
                    TW(customer.What(), false);
                }
                else
                {
                    break;
                }
                WriteLine(ask);

            }
        }

        //  
        public string CustomerGreet(Customer customer)
        {
            return $"{customer.Name}: {customer.assembleGreet()}";
        }

        public void PlaceOnCounter(Customer customer)
        {
            string pronoun = char.ToUpper(PronounCheck((customer.CharDesc()))[0][0]) + PronounCheck((customer.CharDesc()))[0].Substring(1);
            string s = sCheck(pronoun);
            TW($"{customer.Name}: {customer.Place()}\n"); //NAME: {PawnList[customer.ItemIndex].ItemReveal()[0]}
            TW($"{pronoun} place{s} the item on the counter\n");
            foreach (var line in LineBreaker($"Sitting in front of you is {PawnList[customer.ItemIndex].ItemReveal()[1]}"))
            {
                TW($"{line}\n", false);
                
            }
            {
                CurrentBid = customer.Ask();
                TW($"Im wanting around ${CurrentBid}");

            }
        }
        public bool Haggle(Customer customer,Pawnstar pawnstar) //return true if purchase successful
        {
            if (dailyLine.FindIndex(x => x.Name == customer.Name) == 0 && day == 1)
            {
                Clear();
                WriteLine("~~~~HAGGLE TUTORIAL~~~~\nYou can:\n1. Make counter offer - \"How about 500?\"/\"Would you take $2500?\"\n2.Accept their offer - \"It's a deal\"/\"I accept.\"\n3.Call in an expert - \"Let me call my buddy who's an expert\"/\"I want to get another opinion on this\" \n Be careful, because once you accept, there's no backing out!");
                ReadKey();
                Clear();
            
            }
            TW($"Im wanting around ${CurrentBid}");
            Random rand = new Random();
            for(int i = 0; i<rand.Next(3,6); i++) {

                string input = ReadLine();
                int response = Pawnstar.GetHaggleResp(input);

                if(response == 1)   // if has int)
                {
                    int offer = (ExtractInt(input));
                    WriteLine(offer);
                    //method to find int
                            //if (is lower than low go)
                                    
                            //if (is lower than and above lowgo*ask)
                                    //{ set bid to (currentbid-((currentbid-user input) / (random between 1 and 3)))
                                    //ask again
                                    //}
                         //if (is higher)
                             //{rand chance to either accept immideiately or be suspiciaus and ask to call in the expert)
                            
                }
                if(response == 2)
                {
                    WriteLine("you accept");
                    return true;
                }
                if(response == 3)
                {
                    //CallExpert()
                }

                //      

                 

                //}
            }
            //for(random # of time)

            //after loop is fiished, the individual might either leave, or ask to have their item evaluates
            return false;
        }

        public int ExtractInt(string input)
        {
            string intBuild = "";
            foreach (char c in input)
            {
                if (Char.IsDigit(c))
                {
                    intBuild += c;
                }
                else if (input != "")
                {
                    break;
                }
            }
            int result = 0;
            Int32.TryParse(input, out result);
            return result;
        }

    }


}

      

       
