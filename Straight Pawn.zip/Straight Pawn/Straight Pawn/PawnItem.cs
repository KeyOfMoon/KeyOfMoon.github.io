﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Straight_Pawn
{
    class PawnItem
    {
        public string Name, Category, Desc;
        public int TrueValue;
        public PawnItem() { }
        public PawnItem(string name, string category, string desc) //TODO ADD TRUEVALE ,string truevalue
        {
           
            this.Name = name;
            this.Category = category;
            this.Desc = desc;
            //int.TryParse(truevalue, out int intValue);
            //this.TrueValue = intValue;
        }

        public string[] ItemReveal()
        {
            string[] details = {Name,Desc};
            return details;
        }
    }
}
